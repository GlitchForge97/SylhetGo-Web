import { UserCheck, CheckCircle, XCircle, Eye, Award, Star, MapPin } from "lucide-react";

export function GuideVerification() {
  const pendingGuides = [
    {
      id: 1,
      name: "Mohan Kumar Das",
      specialty: "Adventure & Trekking",
      areas: ["Lawachara", "Srimangal"],
      experience: "8 years",
      languages: "Bengali, English, Hindi",
      phone: "+880-1712-XXXXXX",
      appliedDate: "June 4, 2026",
      status: "pending"
    },
    {
      id: 2,
      name: "Salma Khatun",
      specialty: "Haor Navigation",
      areas: ["Ratargul", "Tanguar Haor"],
      experience: "5 years",
      languages: "Bengali, English",
      phone: "+880-1813-XXXXXX",
      appliedDate: "June 3, 2026",
      status: "pending"
    },
    {
      id: 3,
      name: "David Thompson",
      specialty: "Photography Tours",
      areas: ["Jaflong", "Bholaganj", "Sreemangal"],
      experience: "12 years",
      languages: "English, Bengali, French",
      phone: "+880-1923-XXXXXX",
      appliedDate: "June 2, 2026",
      status: "pending"
    },
  ];

  const verifiedGuides = [
    { id: 101, name: "Rafiq Ahmed", specialty: "Tea Estate Expert", rating: 4.9, tours: 340, verified: "2024" },
    { id: 102, name: "Anika Rahman", specialty: "Cultural Heritage", rating: 4.8, tours: 215, verified: "2024" },
    { id: 103, name: "Mohan Das", specialty: "Adventure & Trekking", rating: 4.9, tours: 428, verified: "2023" },
    { id: 104, name: "Salma Begum", specialty: "Haor Navigation", rating: 4.7, tours: 182, verified: "2025" },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h2 className="text-3xl font-semibold text-gray-800 mb-2">Guide Verification Portal</h2>
        <p className="text-gray-600">Review and approve guide applications to maintain service quality</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-md p-6">
          <UserCheck className="w-8 h-8 text-[#0B5345] mb-2" />
          <h3 className="text-2xl font-bold text-gray-800 mb-1">127</h3>
          <p className="text-sm text-gray-600">Verified Guides</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-yellow-500">
          <span className="text-3xl mb-2">⏳</span>
          <h3 className="text-2xl font-bold text-gray-800 mb-1">8</h3>
          <p className="text-sm text-gray-600">Pending Applications</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <Star className="w-8 h-8 text-yellow-500 mb-2" />
          <h3 className="text-2xl font-bold text-gray-800 mb-1">4.8</h3>
          <p className="text-sm text-gray-600">Average Guide Rating</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <Award className="w-8 h-8 text-purple-600 mb-2" />
          <h3 className="text-2xl font-bold text-gray-800 mb-1">23</h3>
          <p className="text-sm text-gray-600">Top Rated (4.9+)</p>
        </div>
      </div>

      {/* Pending Applications */}
      <div className="bg-white rounded-xl shadow-md mb-8">
        <div className="p-6 bg-yellow-500 text-white">
          <h3 className="text-xl font-semibold">Pending Verification Requests</h3>
        </div>

        <div className="p-6 space-y-4">
          {pendingGuides.map((guide) => (
            <div key={guide.id} className="border border-gray-200 rounded-lg p-6 hover:border-[#0B5345] transition-colors">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-start gap-4">
                  <div className="w-16 h-16 bg-[#0B5345] rounded-full flex items-center justify-center text-white text-2xl">
                    {guide.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-xl font-semibold text-gray-800 mb-1">{guide.name}</h4>
                    <p className="text-sm text-gray-600 mb-2">{guide.specialty}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <span>Applied: {guide.appliedDate}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <span className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-xs">
                    Pending Review
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-6 mb-4 p-4 bg-[#F8F9F9] rounded-lg">
                <div>
                  <p className="text-xs text-gray-500 mb-1">Experience</p>
                  <p className="font-semibold text-gray-800">{guide.experience}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Languages</p>
                  <p className="font-semibold text-gray-800">{guide.languages}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Contact</p>
                  <p className="font-semibold text-gray-800">{guide.phone}</p>
                </div>
              </div>

              <div className="mb-4">
                <p className="text-xs text-gray-500 mb-2">Operating Areas</p>
                <div className="flex flex-wrap gap-2">
                  {guide.areas.map((area) => (
                    <span key={area} className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {area}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex gap-3">
                <button className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 transition-colors flex items-center justify-center gap-2 text-sm">
                  <Eye className="w-4 h-4" />
                  View Full Application
                </button>
                <button className="flex-1 bg-red-500 text-white py-2 rounded-lg hover:bg-red-600 transition-colors flex items-center justify-center gap-2 text-sm">
                  <XCircle className="w-4 h-4" />
                  Reject Application
                </button>
                <button className="flex-1 bg-[#2ECC71] text-white py-2 rounded-lg hover:bg-[#27AE60] transition-colors flex items-center justify-center gap-2 text-sm">
                  <CheckCircle className="w-4 h-4" />
                  Grant Verified Badge
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Verified Guides List */}
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6 bg-[#0B5345] text-white flex items-center justify-between">
          <h3 className="text-xl font-semibold">Currently Verified Guides</h3>
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5" />
            <span className="text-sm">SylhetGo Verified</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#F8F9F9]">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Guide Name</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Specialty</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Rating</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Total Tours</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Verified Since</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {verifiedGuides.map((guide) => (
                <tr key={guide.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-[#0B5345] rounded-full flex items-center justify-center text-white">
                        {guide.name.charAt(0)}
                      </div>
                      <span className="font-medium text-gray-800">{guide.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">{guide.specialty}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-yellow-500 text-yellow-500" />
                      <span className="font-semibold text-gray-800">{guide.rating}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-700">{guide.tours} tours</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{guide.verified}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button className="text-blue-600 hover:underline text-sm">View Profile</button>
                      <button className="text-red-600 hover:underline text-sm">Revoke Badge</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-4 bg-[#F8F9F9] border-t border-gray-200">
          <button className="text-[#0B5345] hover:underline text-sm">View All {verifiedGuides.length} Verified Guides</button>
        </div>
      </div>

      {/* Verification Criteria */}
      <div className="mt-8 bg-purple-50 border border-purple-200 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-purple-900 mb-3">Verification Criteria Checklist</h3>
        <div className="grid grid-cols-2 gap-4 text-sm text-purple-800">
          <ul className="space-y-2">
            <li className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 mt-0.5 text-purple-600" />
              <span>Valid government-issued ID verification</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 mt-0.5 text-purple-600" />
              <span>Minimum 2 years of guiding experience</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 mt-0.5 text-purple-600" />
              <span>Language proficiency demonstration</span>
            </li>
          </ul>
          <ul className="space-y-2">
            <li className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 mt-0.5 text-purple-600" />
              <span>Background check clearance</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 mt-0.5 text-purple-600" />
              <span>Reference verification (minimum 2 references)</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 mt-0.5 text-purple-600" />
              <span>First aid certification (recommended)</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
