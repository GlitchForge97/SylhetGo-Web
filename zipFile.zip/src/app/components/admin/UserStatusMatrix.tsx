import { Users, UserCheck, Camera, Activity, TrendingUp, Eye } from "lucide-react";

export function UserStatusMatrix() {
  return (
    <div className="p-8">
      <div className="mb-8">
        <h2 className="text-3xl font-semibold text-gray-800 mb-2">System Overview</h2>
        <p className="text-gray-600">Real-time monitoring of all user panels and system activity</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-xs text-green-600 bg-green-100 px-2 py-1 rounded-full">+12% today</span>
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mb-1">2,847</h3>
          <p className="text-sm text-gray-600">Active Tourists</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <UserCheck className="w-6 h-6 text-green-600" />
            </div>
            <span className="text-xs text-green-600 bg-green-100 px-2 py-1 rounded-full">42 online</span>
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mb-1">127</h3>
          <p className="text-sm text-gray-600">Verified Guides</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <Camera className="w-6 h-6 text-purple-600" />
            </div>
            <span className="text-xs text-green-600 bg-green-100 px-2 py-1 rounded-full">18 active</span>
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mb-1">384</h3>
          <p className="text-sm text-gray-600">Contributors</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <Activity className="w-6 h-6 text-orange-600" />
            </div>
            <span className="text-xs text-yellow-600 bg-yellow-100 px-2 py-1 rounded-full">7 pending</span>
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mb-1">23</h3>
          <p className="text-sm text-gray-600">Moderation Queue</p>
        </div>
      </div>

      {/* Active Sessions Table */}
      <div className="bg-white rounded-xl shadow-md mb-8">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-xl font-semibold text-gray-800">Active User Sessions</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#F8F9F9]">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">User ID</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">User Type</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Current Activity</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Location</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Session Duration</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Status</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              <tr className="hover:bg-gray-50">
                <td className="px-6 py-4 text-sm text-gray-800">TOU_8472</td>
                <td className="px-6 py-4">
                  <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">Tourist</span>
                </td>
                <td className="px-6 py-4 text-sm text-gray-600">Browsing Sreemangal tours</td>
                <td className="px-6 py-4 text-sm text-gray-600">Sylhet City</td>
                <td className="px-6 py-4 text-sm text-gray-600">12m 34s</td>
                <td className="px-6 py-4">
                  <span className="flex items-center gap-2 text-green-600">
                    <span className="w-2 h-2 bg-green-600 rounded-full"></span>
                    Active
                  </span>
                </td>
                <td className="px-6 py-4">
                  <button className="text-[#0B5345] hover:underline text-sm">View Details</button>
                </td>
              </tr>
              <tr className="hover:bg-gray-50">
                <td className="px-6 py-4 text-sm text-gray-800">GUD_2193</td>
                <td className="px-6 py-4">
                  <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs">Guide</span>
                </td>
                <td className="px-6 py-4 text-sm text-gray-600">Managing bookings</td>
                <td className="px-6 py-4 text-sm text-gray-600">Sreemangal</td>
                <td className="px-6 py-4 text-sm text-gray-600">47m 12s</td>
                <td className="px-6 py-4">
                  <span className="flex items-center gap-2 text-green-600">
                    <span className="w-2 h-2 bg-green-600 rounded-full"></span>
                    Active
                  </span>
                </td>
                <td className="px-6 py-4">
                  <button className="text-[#0B5345] hover:underline text-sm">View Details</button>
                </td>
              </tr>
              <tr className="hover:bg-gray-50">
                <td className="px-6 py-4 text-sm text-gray-800">CON_5621</td>
                <td className="px-6 py-4">
                  <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs">Contributor</span>
                </td>
                <td className="px-6 py-4 text-sm text-gray-600">Uploading photos</td>
                <td className="px-6 py-4 text-sm text-gray-600">Ratargul</td>
                <td className="px-6 py-4 text-sm text-gray-600">8m 43s</td>
                <td className="px-6 py-4">
                  <span className="flex items-center gap-2 text-green-600">
                    <span className="w-2 h-2 bg-green-600 rounded-full"></span>
                    Active
                  </span>
                </td>
                <td className="px-6 py-4">
                  <button className="text-[#0B5345] hover:underline text-sm">View Details</button>
                </td>
              </tr>
              <tr className="hover:bg-gray-50">
                <td className="px-6 py-4 text-sm text-gray-800">TOU_3847</td>
                <td className="px-6 py-4">
                  <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">Tourist</span>
                </td>
                <td className="px-6 py-4 text-sm text-gray-600">Viewing fare calculator</td>
                <td className="px-6 py-4 text-sm text-gray-600">Jaflong</td>
                <td className="px-6 py-4 text-sm text-gray-600">3m 18s</td>
                <td className="px-6 py-4">
                  <span className="flex items-center gap-2 text-green-600">
                    <span className="w-2 h-2 bg-green-600 rounded-full"></span>
                    Active
                  </span>
                </td>
                <td className="px-6 py-4">
                  <button className="text-[#0B5345] hover:underline text-sm">View Details</button>
                </td>
              </tr>
              <tr className="hover:bg-gray-50">
                <td className="px-6 py-4 text-sm text-gray-800">GUD_1742</td>
                <td className="px-6 py-4">
                  <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs">Guide</span>
                </td>
                <td className="px-6 py-4 text-sm text-gray-600">Updating profile</td>
                <td className="px-6 py-4 text-sm text-gray-600">Shamshernagar</td>
                <td className="px-6 py-4 text-sm text-gray-600">21m 05s</td>
                <td className="px-6 py-4">
                  <span className="flex items-center gap-2 text-green-600">
                    <span className="w-2 h-2 bg-green-600 rounded-full"></span>
                    Active
                  </span>
                </td>
                <td className="px-6 py-4">
                  <button className="text-[#0B5345] hover:underline text-sm">View Details</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="p-4 bg-[#F8F9F9] border-t border-gray-200">
          <button className="text-[#0B5345] hover:underline text-sm">View All Sessions (127 active)</button>
        </div>
      </div>

      {/* System Analytics */}
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center gap-3 mb-6">
            <TrendingUp className="w-6 h-6 text-[#0B5345]" />
            <h3 className="text-xl font-semibold text-gray-800">User Growth (Last 30 Days)</h3>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Tourists</span>
                <span className="text-sm font-semibold text-gray-800">+347 new</span>
              </div>
              <div className="bg-gray-200 rounded-full h-2">
                <div className="bg-blue-500 h-2 rounded-full" style={{ width: "78%" }}></div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Guides</span>
                <span className="text-sm font-semibold text-gray-800">+12 new</span>
              </div>
              <div className="bg-gray-200 rounded-full h-2">
                <div className="bg-green-500 h-2 rounded-full" style={{ width: "42%" }}></div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Contributors</span>
                <span className="text-sm font-semibold text-gray-800">+28 new</span>
              </div>
              <div className="bg-gray-200 rounded-full h-2">
                <div className="bg-purple-500 h-2 rounded-full" style={{ width: "56%" }}></div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center gap-3 mb-6">
            <Eye className="w-6 h-6 text-[#0B5345]" />
            <h3 className="text-xl font-semibold text-gray-800">Panel Activity Today</h3>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
              <div>
                <p className="font-semibold text-gray-800">Tourist Panel</p>
                <p className="text-sm text-gray-600">2,847 active users</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-blue-600">84%</p>
                <p className="text-xs text-gray-600">Engagement</p>
              </div>
            </div>

            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
              <div>
                <p className="font-semibold text-gray-800">Guide Panel</p>
                <p className="text-sm text-gray-600">42 active users</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-green-600">92%</p>
                <p className="text-xs text-gray-600">Engagement</p>
              </div>
            </div>

            <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
              <div>
                <p className="font-semibold text-gray-800">Contributor Panel</p>
                <p className="text-sm text-gray-600">18 active users</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-purple-600">67%</p>
                <p className="text-xs text-gray-600">Engagement</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
