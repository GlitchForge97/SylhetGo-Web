import { DollarSign, Edit2, Save, Plus, Trash2, MapPin } from "lucide-react";
import { useState } from "react";

export function FareManager() {
  const [routes, setRoutes] = useState([
    { id: 1, from: "Sylhet", to: "Ratargul", distance: "26 km", cngFare: "350-400", boatFare: "500/boat", duration: "45 min", active: true },
    { id: 2, from: "Sylhet", to: "Jaflong", distance: "62 km", cngFare: "800-900", boatFare: "N/A", duration: "1.5 hr", active: true },
    { id: 3, from: "Sylhet", to: "Sreemangal", distance: "85 km", cngFare: "1100-1200", boatFare: "N/A", duration: "2 hr", active: true },
    { id: 4, from: "Sylhet", to: "Bholaganj", distance: "38 km", cngFare: "500-600", boatFare: "N/A", duration: "1 hr", active: true },
    { id: 5, from: "Sylhet", to: "Shamshernagar", distance: "92 km", cngFare: "1200-1300", boatFare: "N/A", duration: "2.2 hr", active: true },
  ]);

  const [editingId, setEditingId] = useState<number | null>(null);

  return (
    <div className="p-8">
      <div className="mb-8">
        <h2 className="text-3xl font-semibold text-gray-800 mb-2">Fare & Route Management</h2>
        <p className="text-gray-600">Manage transport fares and routes to ensure transparent pricing for tourists</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center justify-between mb-2">
            <DollarSign className="w-8 h-8 text-[#0B5345]" />
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mb-1">47</h3>
          <p className="text-sm text-gray-600">Active Routes</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center justify-between mb-2">
            <MapPin className="w-8 h-8 text-blue-600" />
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mb-1">23</h3>
          <p className="text-sm text-gray-600">CNG Operators</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-3xl">🚤</span>
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mb-1">15</h3>
          <p className="text-sm text-gray-600">Boat Services</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6 bg-gradient-to-br from-[#0B5345] to-[#2ECC71] text-white">
          <p className="text-sm mb-2">Last Updated</p>
          <h3 className="text-lg font-bold">2 days ago</h3>
        </div>
      </div>

      {/* Add New Route Button */}
      <div className="mb-6">
        <button className="bg-[#2ECC71] text-white px-6 py-3 rounded-lg hover:bg-[#27AE60] transition-colors flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Add New Route
        </button>
      </div>

      {/* Routes Table */}
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6 bg-[#0B5345] text-white">
          <h3 className="text-xl font-semibold">Active Transport Routes</h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#F8F9F9]">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Route</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Distance</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">CNG Fare (৳)</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Boat Fare (৳)</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Duration</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Status</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {routes.map((route) => (
                <tr key={route.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    {editingId === route.id ? (
                      <div className="flex gap-2">
                        <input
                          type="text"
                          defaultValue={route.from}
                          className="w-24 px-2 py-1 border border-gray-300 rounded text-sm"
                        />
                        <span>→</span>
                        <input
                          type="text"
                          defaultValue={route.to}
                          className="w-24 px-2 py-1 border border-gray-300 rounded text-sm"
                        />
                      </div>
                    ) : (
                      <span className="font-medium text-gray-800">{route.from} → {route.to}</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    {editingId === route.id ? (
                      <input
                        type="text"
                        defaultValue={route.distance}
                        className="w-20 px-2 py-1 border border-gray-300 rounded text-sm"
                      />
                    ) : (
                      <span className="text-gray-600">{route.distance}</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    {editingId === route.id ? (
                      <input
                        type="text"
                        defaultValue={route.cngFare}
                        className="w-28 px-2 py-1 border border-gray-300 rounded text-sm font-semibold text-[#0B5345]"
                      />
                    ) : (
                      <span className="font-semibold text-[#0B5345]">৳{route.cngFare}</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    {editingId === route.id ? (
                      <input
                        type="text"
                        defaultValue={route.boatFare}
                        className="w-28 px-2 py-1 border border-gray-300 rounded text-sm font-semibold text-[#0B5345]"
                      />
                    ) : (
                      <span className={`font-semibold ${route.boatFare === 'N/A' ? 'text-gray-400' : 'text-[#0B5345]'}`}>
                        {route.boatFare === 'N/A' ? 'N/A' : `৳${route.boatFare}`}
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    {editingId === route.id ? (
                      <input
                        type="text"
                        defaultValue={route.duration}
                        className="w-20 px-2 py-1 border border-gray-300 rounded text-sm"
                      />
                    ) : (
                      <span className="text-gray-600">{route.duration}</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs ${
                      route.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {route.active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      {editingId === route.id ? (
                        <button
                          onClick={() => setEditingId(null)}
                          className="p-2 bg-[#2ECC71] text-white rounded-lg hover:bg-[#27AE60] transition-colors"
                          title="Save"
                        >
                          <Save className="w-4 h-4" />
                        </button>
                      ) : (
                        <button
                          onClick={() => setEditingId(route.id)}
                          className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-colors"
                          title="Edit"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                      )}
                      <button
                        className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-6 bg-[#F8F9F9] border-t border-gray-200">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-600">
              Showing {routes.length} routes. Last fare update: June 5, 2026
            </p>
            <button className="bg-[#0B5345] text-white px-6 py-2 rounded-lg hover:bg-[#0a4538] transition-colors">
              Save All Changes
            </button>
          </div>
        </div>
      </div>

      {/* Pricing Guidelines */}
      <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-blue-900 mb-3">Fare Update Guidelines</h3>
        <ul className="text-sm text-blue-800 space-y-2">
          <li>• Fares should be updated quarterly or when significant market changes occur</li>
          <li>• CNG fares typically range ৳12-15 per kilometer</li>
          <li>• Boat fares are per boat (capacity 4-6 passengers) for Ratargul and similar destinations</li>
          <li>• Always verify fares with at least 3 operators before updating</li>
          <li>• Document the source and date of fare verification in the system notes</li>
        </ul>
      </div>
    </div>
  );
}
