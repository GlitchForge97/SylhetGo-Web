import { MapPin, Upload, Image as ImageIcon, Plus, Eye, Edit2, Trash2 } from "lucide-react";

export function SpotPublisher() {
  const existingSpots = [
    { id: 1, name: "Ratargul Swamp Forest", location: "Gowainghat, Sylhet", status: "Published", photos: 12, views: 8420 },
    { id: 2, name: "Jaflong", location: "Gowainghat, Sylhet", status: "Published", photos: 18, views: 15230 },
    { id: 3, name: "Sreemangal Tea Estates", location: "Sreemangal, Moulvibazar", status: "Published", photos: 24, views: 12840 },
    { id: 4, name: "Bholaganj Sada Pathor", location: "Companiganj, Sylhet", status: "Published", photos: 9, views: 6720 },
    { id: 5, name: "Shamshernagar Heritage Site", location: "Shamshernagar, Moulvibazar", status: "Draft", photos: 5, views: 0 },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h2 className="text-3xl font-semibold text-gray-800 mb-2">Spot & Content Publisher</h2>
        <p className="text-gray-600">Add and manage destination listings with high-quality imagery</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-md p-6">
          <MapPin className="w-8 h-8 text-[#0B5345] mb-2" />
          <h3 className="text-2xl font-bold text-gray-800 mb-1">47</h3>
          <p className="text-sm text-gray-600">Published Spots</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <ImageIcon className="w-8 h-8 text-blue-600 mb-2" />
          <h3 className="text-2xl font-bold text-gray-800 mb-1">328</h3>
          <p className="text-sm text-gray-600">Total Photos</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <Eye className="w-8 h-8 text-purple-600 mb-2" />
          <h3 className="text-2xl font-bold text-gray-800 mb-1">142K</h3>
          <p className="text-sm text-gray-600">Total Views</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <span className="text-3xl mb-2">📝</span>
          <h3 className="text-2xl font-bold text-gray-800 mb-1">3</h3>
          <p className="text-sm text-gray-600">Draft Spots</p>
        </div>
      </div>

      {/* Add New Spot Form */}
      <div className="bg-white rounded-xl shadow-md p-6 mb-8">
        <div className="flex items-center gap-3 mb-6">
          <Plus className="w-6 h-6 text-[#0B5345]" />
          <h3 className="text-xl font-semibold text-gray-800">Add New Destination</h3>
        </div>

        <div className="grid grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Spot Name *</label>
              <input
                type="text"
                placeholder="e.g., Sreemangal Tea Estates"
                className="w-full px-4 py-3 bg-[#F8F9F9] rounded-lg outline-none focus:ring-2 focus:ring-[#0B5345]"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Location *</label>
              <input
                type="text"
                placeholder="e.g., Sreemangal, Moulvibazar"
                className="w-full px-4 py-3 bg-[#F8F9F9] rounded-lg outline-none focus:ring-2 focus:ring-[#0B5345]"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">GPS Coordinates</label>
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="Latitude"
                  className="px-4 py-3 bg-[#F8F9F9] rounded-lg outline-none focus:ring-2 focus:ring-[#0B5345]"
                />
                <input
                  type="text"
                  placeholder="Longitude"
                  className="px-4 py-3 bg-[#F8F9F9] rounded-lg outline-none focus:ring-2 focus:ring-[#0B5345]"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Category *</label>
              <select className="w-full px-4 py-3 bg-[#F8F9F9] rounded-lg outline-none focus:ring-2 focus:ring-[#0B5345]">
                <option>Select category...</option>
                <option>Nature & Wildlife</option>
                <option>Spiritual & Heritage</option>
                <option>Adventure & Trekking</option>
                <option>Cultural Experience</option>
                <option>Tea Tourism</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Best Time to Visit *</label>
              <input
                type="text"
                placeholder="e.g., October to April"
                className="w-full px-4 py-3 bg-[#F8F9F9] rounded-lg outline-none focus:ring-2 focus:ring-[#0B5345]"
              />
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Description *</label>
              <textarea
                rows={6}
                placeholder="Provide a detailed, engaging description of the destination..."
                className="w-full px-4 py-3 bg-[#F8F9F9] rounded-lg outline-none focus:ring-2 focus:ring-[#0B5345]"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Upload High-Resolution Photographs *</label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-[#0B5345] transition-colors cursor-pointer">
                <ImageIcon className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-600 mb-2">Drag realistic local photography here</p>
                <p className="text-xs text-gray-500 mb-3">
                  Upload photos of actual Sreemangal tea estates, Shamshernagar lakes, Ratargul swamp forest, etc.
                </p>
                <button className="bg-[#0B5345] text-white px-6 py-2 rounded-lg hover:bg-[#0a4538] transition-colors flex items-center gap-2 mx-auto">
                  <Upload className="w-4 h-4" />
                  Choose Files
                </button>
                <p className="text-xs text-gray-500 mt-2">Minimum 3 photos, maximum 20. Each up to 15MB.</p>
              </div>
            </div>

            <div className="flex gap-3">
              <button className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 transition-colors">
                Save as Draft
              </button>
              <button className="flex-1 bg-[#2ECC71] text-white py-3 rounded-lg hover:bg-[#27AE60] transition-colors">
                Publish Spot
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Existing Spots Management */}
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6 bg-[#0B5345] text-white">
          <h3 className="text-xl font-semibold">Manage Existing Spots</h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#F8F9F9]">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Spot Name</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Location</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Photos</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Total Views</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Status</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {existingSpots.map((spot) => (
                <tr key={spot.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <MapPin className="w-5 h-5 text-[#0B5345]" />
                      <span className="font-medium text-gray-800">{spot.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">{spot.location}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <ImageIcon className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-700">{spot.photos} photos</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <Eye className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-700">{spot.views.toLocaleString()}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs ${
                      spot.status === 'Published'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-yellow-100 text-yellow-700'
                    }`}>
                      {spot.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button
                        className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-colors"
                        title="Edit"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        className="p-2 bg-purple-100 text-purple-600 rounded-lg hover:bg-purple-200 transition-colors"
                        title="Preview"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Content Guidelines */}
      <div className="mt-8 bg-green-50 border border-green-200 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-green-900 mb-3">Content Quality Guidelines</h3>
        <ul className="text-sm text-green-800 space-y-2">
          <li>• Use realistic, high-resolution photography from actual locations (Sreemangal tea estates, Shamshernagar lakes, Ratargul swamp)</li>
          <li>• Avoid generic stock images - prioritize authentic local photography</li>
          <li>• Provide accurate GPS coordinates for navigation purposes</li>
          <li>• Include seasonal accessibility information (especially for Haor areas)</li>
          <li>• Highlight unique local features and indigenous cultural aspects</li>
        </ul>
      </div>
    </div>
  );
}
