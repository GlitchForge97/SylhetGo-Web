import { MessageSquare, CheckCircle, XCircle, Eye, AlertTriangle, Image as ImageIcon, Flag, Edit2 } from "lucide-react";

export function CommunityModeration() {
  const pendingReviews = [
    {
      id: 1,
      type: "Photo Upload",
      user: "TravelExplorer_BD",
      location: "Sreemangal Tea Estates",
      content: "Amazing sunrise view over the tea gardens. The morning mist creates a magical atmosphere!",
      timestamp: "2 hours ago",
      photoCount: 3,
      status: "pending"
    },
    {
      id: 2,
      type: "Community Update",
      user: "LocalGuide_Rafiq",
      location: "Ratargul Swamp Forest",
      content: "Water levels are perfect this week for boat tours. Best time to visit is early morning before 9 AM.",
      timestamp: "4 hours ago",
      photoCount: 0,
      status: "pending"
    },
    {
      id: 3,
      type: "Hazard Report",
      user: "SafetyFirst_User",
      location: "Jaflong Road",
      content: "Road construction ongoing near Jaflong entrance. Expect 20-30 minute delays during 10 AM - 4 PM.",
      timestamp: "6 hours ago",
      photoCount: 2,
      status: "pending",
      priority: "high"
    },
    {
      id: 4,
      type: "Travel Review",
      user: "Wanderer_Sarah",
      location: "Bholaganj Sada Pathor",
      content: "Crystal clear water and stunning white stones. Guide 'Mohan' was excellent - very knowledgeable about local geology!",
      timestamp: "8 hours ago",
      photoCount: 5,
      status: "pending"
    },
  ];

  const flaggedContent = [
    {
      id: 501,
      type: "Comment",
      user: "Anonymous_User",
      reason: "Inappropriate language",
      flaggedBy: 3,
      content: "This place is overrated and the guides are...",
      timestamp: "1 day ago"
    },
    {
      id: 502,
      type: "Photo",
      user: "PhotoSpammer_123",
      reason: "Spam/Advertising",
      flaggedBy: 7,
      content: "Multiple photos with commercial watermarks",
      timestamp: "2 days ago"
    },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h2 className="text-3xl font-semibold text-gray-800 mb-2">Community Moderation Queue</h2>
        <p className="text-gray-600">Review and approve user-generated content before it goes live</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-md p-6">
          <MessageSquare className="w-8 h-8 text-[#0B5345] mb-2" />
          <h3 className="text-2xl font-bold text-gray-800 mb-1">23</h3>
          <p className="text-sm text-gray-600">Pending Reviews</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-red-500">
          <Flag className="w-8 h-8 text-red-500 mb-2" />
          <h3 className="text-2xl font-bold text-gray-800 mb-1">5</h3>
          <p className="text-sm text-gray-600">Flagged Content</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <CheckCircle className="w-8 h-8 text-green-600 mb-2" />
          <h3 className="text-2xl font-bold text-gray-800 mb-1">1,847</h3>
          <p className="text-sm text-gray-600">Approved (30 days)</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <XCircle className="w-8 h-8 text-gray-500 mb-2" />
          <h3 className="text-2xl font-bold text-gray-800 mb-1">42</h3>
          <p className="text-sm text-gray-600">Rejected (30 days)</p>
        </div>
      </div>

      {/* Flagged Content (Priority) */}
      {flaggedContent.length > 0 && (
        <div className="bg-white rounded-xl shadow-md mb-8 border-l-4 border-red-500">
          <div className="p-6 bg-red-500 text-white">
            <div className="flex items-center gap-3">
              <Flag className="w-6 h-6" />
              <h3 className="text-xl font-semibold">Flagged Content - Requires Immediate Attention</h3>
            </div>
          </div>

          <div className="p-6 space-y-4">
            {flaggedContent.map((item) => (
              <div key={item.id} className="border border-red-200 rounded-lg p-5 bg-red-50">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <span className="px-3 py-1 bg-red-600 text-white rounded-full text-xs">
                        {item.type}
                      </span>
                      <span className="text-sm text-gray-600">by {item.user}</span>
                    </div>
                    <p className="text-sm text-gray-800 mb-2">
                      <span className="font-semibold">Reason:</span> {item.reason}
                    </p>
                    <p className="text-sm text-gray-600 italic">"{item.content}"</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-500 mb-1">{item.timestamp}</p>
                    <p className="text-xs text-red-600 font-semibold">
                      Flagged by {item.flaggedBy} users
                    </p>
                  </div>
                </div>

                <div className="flex gap-2 mt-4">
                  <button className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 transition-colors text-sm">
                    Dismiss Flags
                  </button>
                  <button className="flex-1 bg-yellow-500 text-white py-2 rounded-lg hover:bg-yellow-600 transition-colors text-sm">
                    Request Edit
                  </button>
                  <button className="flex-1 bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 transition-colors text-sm">
                    Remove Content
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Pending Reviews Queue */}
      <div className="bg-white rounded-xl shadow-md">
        <div className="p-6 bg-[#0B5345] text-white">
          <h3 className="text-xl font-semibold">Content Approval Queue</h3>
        </div>

        <div className="p-6 space-y-4">
          {pendingReviews.map((item) => (
            <div
              key={item.id}
              className={`border rounded-lg p-5 hover:border-[#0B5345] transition-colors ${
                item.priority === 'high' ? 'border-yellow-400 bg-yellow-50' : 'border-gray-200'
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className={`px-3 py-1 rounded-full text-xs ${
                      item.type === 'Photo Upload' ? 'bg-blue-100 text-blue-700' :
                      item.type === 'Community Update' ? 'bg-green-100 text-green-700' :
                      item.type === 'Hazard Report' ? 'bg-red-100 text-red-700' :
                      'bg-purple-100 text-purple-700'
                    }`}>
                      {item.type}
                    </span>
                    {item.priority === 'high' && (
                      <span className="flex items-center gap-1 px-3 py-1 bg-yellow-500 text-white rounded-full text-xs">
                        <AlertTriangle className="w-3 h-3" />
                        High Priority
                      </span>
                    )}
                  </div>

                  <div className="mb-3">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold text-gray-800">{item.user}</span>
                      <span className="text-gray-400">•</span>
                      <span className="text-sm text-gray-600">{item.location}</span>
                      <span className="text-gray-400">•</span>
                      <span className="text-xs text-gray-500">{item.timestamp}</span>
                    </div>
                    {item.photoCount > 0 && (
                      <div className="flex items-center gap-1 text-xs text-gray-600">
                        <ImageIcon className="w-3 h-3" />
                        <span>{item.photoCount} photos attached</span>
                      </div>
                    )}
                  </div>

                  <p className="text-gray-700 bg-white p-3 rounded-lg border border-gray-200">
                    "{item.content}"
                  </p>
                </div>
              </div>

              <div className="flex gap-2">
                <button className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 transition-colors flex items-center justify-center gap-2 text-sm">
                  <Eye className="w-4 h-4" />
                  {item.photoCount > 0 ? 'View Photos' : 'View Full Details'}
                </button>
                <button className="flex-1 bg-yellow-500 text-white py-2 rounded-lg hover:bg-yellow-600 transition-colors flex items-center justify-center gap-2 text-sm">
                  <Edit2 className="w-4 h-4" />
                  Request Edits
                </button>
                <button className="flex-1 bg-red-500 text-white py-2 rounded-lg hover:bg-red-600 transition-colors flex items-center justify-center gap-2 text-sm">
                  <XCircle className="w-4 h-4" />
                  Reject
                </button>
                <button className="flex-1 bg-[#2ECC71] text-white py-2 rounded-lg hover:bg-[#27AE60] transition-colors flex items-center justify-center gap-2 text-sm">
                  <CheckCircle className="w-4 h-4" />
                  Approve & Publish
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 bg-[#F8F9F9] border-t border-gray-200">
          <div className="flex items-center justify-between">
            <button className="text-[#0B5345] hover:underline text-sm">
              View All Pending ({pendingReviews.length + 19} total)
            </button>
            <div className="flex gap-3">
              <button className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors text-sm">
                Reject All
              </button>
              <button className="bg-[#2ECC71] text-white px-4 py-2 rounded-lg hover:bg-[#27AE60] transition-colors text-sm">
                Approve All
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Moderation Guidelines */}
      <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-blue-900 mb-3">Content Moderation Standards</h3>
        <div className="grid grid-cols-2 gap-4 text-sm text-blue-800">
          <ul className="space-y-2">
            <li>• <strong>Approve:</strong> Accurate information, helpful tips, quality photos</li>
            <li>• <strong>Request Edit:</strong> Minor inaccuracies, unclear descriptions, low-quality images</li>
            <li>• <strong>Reject:</strong> Spam, inappropriate content, false information, commercial advertising</li>
          </ul>
          <ul className="space-y-2">
            <li>• Review hazard reports within 2 hours (high priority)</li>
            <li>• Photo uploads should show authentic local scenery</li>
            <li>• Community updates must be factual and verifiable</li>
            <li>• All flagged content requires immediate admin review</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
