import { Search, MapPin, Calendar, DollarSign, Leaf, Mountain, Droplets, Users, Star } from "lucide-react";
import { Link } from "react-router";
import { DemoAccessPanel } from "./DemoAccessPanel";

export function TouristPanel() {
  return (
    <div className="min-h-screen bg-white">
      <DemoAccessPanel />
      {/* Navigation Header */}
      <nav className="bg-[#0B5345] text-white px-8 py-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Leaf className="w-8 h-8" />
            <div>
              <h1 className="text-xl font-semibold">SylhetGo</h1>
              <p className="text-xs text-white/80">The Ultimate Smart Tourism Portal</p>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <Link to="/guide" className="text-sm hover:text-[#2ECC71] transition-colors">Guide Login</Link>
            <Link to="/contributor" className="text-sm hover:text-[#2ECC71] transition-colors">Contributor Login</Link>
            <button className="bg-[#2ECC71] px-4 py-2 rounded-lg text-sm hover:bg-[#27AE60] transition-colors">
              Get Started
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#0B5345] to-[#1a7a63] text-white py-24">
        <div className="max-w-7xl mx-auto px-8">
          <div className="max-w-3xl">
            <h2 className="text-5xl font-bold mb-4">One Web. All of Sylhet.</h2>
            <p className="text-xl text-white/90 mb-8">
              Discover authentic experiences, verified guides, and transparent pricing across Sylhet's most breathtaking destinations.
            </p>

            {/* Search Bar */}
            <div className="bg-white rounded-xl p-2 flex items-center gap-3 shadow-2xl">
              <Search className="w-5 h-5 text-gray-400 ml-2" />
              <input
                type="text"
                placeholder="Search destinations, guides, or experiences..."
                className="flex-1 px-3 py-3 text-gray-800 outline-none"
              />
              <div className="flex items-center gap-2 pr-2">
                <select className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg outline-none cursor-pointer">
                  <option>All Types</option>
                  <option>Nature</option>
                  <option>Spiritual</option>
                  <option>Adventure</option>
                  <option>Heritage</option>
                </select>
                <button className="bg-[#2ECC71] px-6 py-2 rounded-lg hover:bg-[#27AE60] transition-colors">
                  Search
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Local Highlights */}
      <section className="max-w-7xl mx-auto px-8 py-16">
        <h3 className="text-3xl font-semibold text-gray-800 mb-8">Featured Local Highlights</h3>

        <div className="grid grid-cols-2 gap-8 mb-16">
          {/* Sreemangal Card */}
          <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-shadow">
            <div className="relative h-80">
              <img
                src="https://images.unsplash.com/photo-1491497895121-1334fc14d8c9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWElMjBwbGFudGF0aW9uJTIwZ3JlZW4lMjBoaWxscyUyMHNjZW5pY3xlbnwxfHx8fDE3ODA4MDgxODN8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Sreemangal Tea Estates"
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 right-4 bg-[#2ECC71] text-white px-3 py-1 rounded-full text-sm">
                Featured
              </div>
            </div>
            <div className="p-6">
              <h4 className="text-2xl font-semibold text-gray-800 mb-2">Sreemangal: The Tea Capital</h4>
              <p className="text-gray-600 mb-4">
                Explore rolling tea estates, cycle through Lawachara National Park, and experience authentic tea cabin culture in Bangladesh's premier tea region.
              </p>
              <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                <span className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  85km from Sylhet
                </span>
                <span className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-yellow-500" />
                  4.8 (1,240 reviews)
                </span>
              </div>
              <button className="w-full bg-[#0B5345] text-white py-3 rounded-lg hover:bg-[#0a4538] transition-colors">
                Explore Sreemangal
              </button>
            </div>
          </div>

          {/* Shamshernagar Card */}
          <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-shadow">
            <div className="relative h-80">
              <img
                src="https://images.unsplash.com/photo-1658051161493-1d311c4c7b4d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHw0fHx0ZWElMjBwbGFudGF0aW9uJTIwZ3JlZW4lMjBoaWxscyUyMHNjZW5pY3xlbnwxfHx8fDE3ODA4MDgxODN8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Shamshernagar Heritage"
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 right-4 bg-[#2ECC71] text-white px-3 py-1 rounded-full text-sm">
                Hidden Gem
              </div>
            </div>
            <div className="p-6">
              <h4 className="text-2xl font-semibold text-gray-800 mb-2">Shamshernagar: The Hidden Heritage</h4>
              <p className="text-gray-600 mb-4">
                Discover serene tea garden lakes, historic airport landmarks, indigenous culture, and peaceful landscapes in this underrated destination.
              </p>
              <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                <span className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  92km from Sylhet
                </span>
                <span className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-yellow-500" />
                  4.6 (387 reviews)
                </span>
              </div>
              <button className="w-full bg-[#0B5345] text-white py-3 rounded-lg hover:bg-[#0a4538] transition-colors">
                Explore Shamshernagar
              </button>
            </div>
          </div>
        </div>

        {/* Main Attractions Grid */}
        <h3 className="text-3xl font-semibold text-gray-800 mb-8">Main Attractions</h3>
        <div className="grid grid-cols-3 gap-6 mb-16">
          <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow">
            <div className="relative h-48">
              <img
                src="https://images.unsplash.com/photo-1543777166-81504743e51e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzd2FtcCUyMGZvcmVzdCUyMHdhdGVyJTIwdHJlZXMlMjBuYXR1cmV8ZW58MXx8fHwxNzgwODA4MTg0fDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Ratargul Swamp Forest"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-5">
              <h5 className="text-lg font-semibold text-gray-800 mb-2">Ratargul Swamp Forest</h5>
              <p className="text-sm text-gray-600 mb-3">Experience Bangladesh's only freshwater swamp forest by boat</p>
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">Best: Oct-Apr</span>
                <button className="text-[#2ECC71] text-sm hover:underline">View Details</button>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow">
            <div className="relative h-48">
              <img
                src="https://images.unsplash.com/photo-1516483797183-de683a8ef229?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyaXZlciUyMHN0b25lcyUyMG1vdW50YWlucyUyMGxhbmRzY2FwZXxlbnwxfHx8fDE3ODA4MDgxODR8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Jaflong"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-5">
              <h5 className="text-lg font-semibold text-gray-800 mb-2">Jaflong</h5>
              <p className="text-sm text-gray-600 mb-3">Stunning river views, stone collection, and mountain panoramas</p>
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">Best: Year-round</span>
                <button className="text-[#2ECC71] text-sm hover:underline">View Details</button>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow">
            <div className="relative h-48">
              <img
                src="https://images.unsplash.com/photo-1566076009300-e313adb6f2a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHw0fHxyaXZlciUyMHN0b25lcyUyMG1vdW50YWlucyUyMGxhbmRzY2FwZXxlbnwxfHx8fDE3ODA4MDgxODR8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Bholaganj Sada Pathor"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-5">
              <h5 className="text-lg font-semibold text-gray-800 mb-2">Bholaganj Sada Pathor</h5>
              <p className="text-sm text-gray-600 mb-3">White stone quarries with crystal-clear river waters</p>
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">Best: Nov-Mar</span>
                <button className="text-[#2ECC71] text-sm hover:underline">View Details</button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Transport & Pricing Section */}
      <section className="bg-[#F8F9F9] py-16">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex items-center gap-3 mb-8">
            <DollarSign className="w-8 h-8 text-[#0B5345]" />
            <h3 className="text-3xl font-semibold text-gray-800">Zone-Based Transport Pricing</h3>
          </div>
          <p className="text-gray-600 mb-8">Transparent, verified fares to eliminate tourist overcharging</p>

          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <table className="w-full">
              <thead className="bg-[#0B5345] text-white">
                <tr>
                  <th className="px-6 py-4 text-left">Route</th>
                  <th className="px-6 py-4 text-left">Distance</th>
                  <th className="px-6 py-4 text-left">CNG Fare</th>
                  <th className="px-6 py-4 text-left">Boat Fare</th>
                  <th className="px-6 py-4 text-left">Duration</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr className="hover:bg-gray-50">
                  <td className="px-6 py-4">Sylhet → Ratargul</td>
                  <td className="px-6 py-4">26 km</td>
                  <td className="px-6 py-4 font-semibold text-[#0B5345]">৳350-400</td>
                  <td className="px-6 py-4 font-semibold text-[#0B5345]">৳500/boat</td>
                  <td className="px-6 py-4 text-gray-600">45 min</td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="px-6 py-4">Sylhet → Jaflong</td>
                  <td className="px-6 py-4">62 km</td>
                  <td className="px-6 py-4 font-semibold text-[#0B5345]">৳800-900</td>
                  <td className="px-6 py-4 text-gray-400">N/A</td>
                  <td className="px-6 py-4 text-gray-600">1.5 hr</td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="px-6 py-4">Sylhet → Sreemangal</td>
                  <td className="px-6 py-4">85 km</td>
                  <td className="px-6 py-4 font-semibold text-[#0B5345]">৳1,100-1,200</td>
                  <td className="px-6 py-4 text-gray-400">N/A</td>
                  <td className="px-6 py-4 text-gray-600">2 hr</td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="px-6 py-4">Sylhet → Bholaganj</td>
                  <td className="px-6 py-4">38 km</td>
                  <td className="px-6 py-4 font-semibold text-[#0B5345]">৳500-600</td>
                  <td className="px-6 py-4 text-gray-400">N/A</td>
                  <td className="px-6 py-4 text-gray-600">1 hr</td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="px-6 py-4">Sylhet → Shamshernagar</td>
                  <td className="px-6 py-4">92 km</td>
                  <td className="px-6 py-4 font-semibold text-[#0B5345]">৳1,200-1,300</td>
                  <td className="px-6 py-4 text-gray-400">N/A</td>
                  <td className="px-6 py-4 text-gray-600">2.2 hr</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Haor Season Tracker */}
      <section className="max-w-7xl mx-auto px-8 py-16">
        <div className="flex items-center gap-3 mb-8">
          <Droplets className="w-8 h-8 text-[#0B5345]" />
          <h3 className="text-3xl font-semibold text-gray-800">Haor Season Tracker</h3>
        </div>
        <p className="text-gray-600 mb-8">Real-time accessibility based on monsoon water levels</p>

        <div className="bg-gradient-to-r from-[#0B5345] to-[#2ECC71] rounded-xl p-8 text-white">
          <div className="grid grid-cols-12 gap-2 mb-6">
            {["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"].map((month, idx) => (
              <div key={month} className="text-center">
                <div className={`h-24 rounded-lg mb-2 ${
                  idx >= 5 && idx <= 8 ? 'bg-red-500' :
                  idx >= 3 && idx <= 4 || idx >= 9 && idx <= 10 ? 'bg-yellow-500' :
                  'bg-green-500'
                }`}></div>
                <span className="text-xs">{month}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-center gap-8 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-green-500 rounded"></div>
              <span>Fully Accessible</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-yellow-500 rounded"></div>
              <span>Partially Accessible</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-red-500 rounded"></div>
              <span>Limited Access (Monsoon)</span>
            </div>
          </div>
        </div>
      </section>

      {/* Verified Guides Directory */}
      <section className="bg-[#F8F9F9] py-16">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex items-center gap-3 mb-8">
            <Users className="w-8 h-8 text-[#0B5345]" />
            <h3 className="text-3xl font-semibold text-gray-800">Verified Local Guides</h3>
          </div>

          <div className="grid grid-cols-4 gap-6">
            {[
              { name: "Rafiq Ahmed", specialty: "Tea Estate Expert", rating: 4.9, tours: 340 },
              { name: "Anika Rahman", specialty: "Cultural Heritage", rating: 4.8, tours: 215 },
              { name: "Mohan Das", specialty: "Adventure & Trekking", rating: 4.9, tours: 428 },
              { name: "Salma Begum", specialty: "Haor Navigation", rating: 4.7, tours: 182 },
            ].map((guide) => (
              <div key={guide.name} className="bg-white rounded-xl p-5 shadow-md hover:shadow-xl transition-shadow">
                <div className="w-16 h-16 bg-[#0B5345] rounded-full mx-auto mb-3 flex items-center justify-center text-white text-xl">
                  {guide.name.charAt(0)}
                </div>
                <h5 className="text-center font-semibold text-gray-800 mb-1">{guide.name}</h5>
                <p className="text-center text-sm text-gray-600 mb-3">{guide.specialty}</p>
                <div className="flex items-center justify-center gap-1 mb-2">
                  <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                  <span className="text-sm font-semibold">{guide.rating}</span>
                  <span className="text-xs text-gray-500">({guide.tours} tours)</span>
                </div>
                <div className="bg-[#2ECC71] text-white text-xs px-3 py-1 rounded-full text-center">
                  SylhetGo Verified
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Community Board */}
      <section className="max-w-7xl mx-auto px-8 py-16">
        <h3 className="text-3xl font-semibold text-gray-800 mb-8">Live Community Updates</h3>

        <div className="space-y-4">
          {[
            { user: "Traveler_Mike", time: "2 hours ago", update: "Just visited Jaflong - water levels perfect! Crystal clear views of the stones. Highly recommend going this week." },
            { user: "LocalExpert_BD", time: "5 hours ago", update: "Flash flood warning issued for Ratargul area. Best to postpone boat tours for the next 48 hours." },
            { user: "TeaLover_Sarah", time: "1 day ago", update: "Finlay Tea Estate in Sreemangal is stunning right now. Fresh tea picking season has started!" },
          ].map((post, idx) => (
            <div key={idx} className="bg-white rounded-xl p-6 shadow-md border-l-4 border-[#2ECC71]">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#0B5345] rounded-full flex items-center justify-center text-white">
                    {post.user.charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-800">{post.user}</p>
                    <p className="text-xs text-gray-500">{post.time}</p>
                  </div>
                </div>
              </div>
              <p className="text-gray-700">{post.update}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0B5345] text-white py-12">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-semibold mb-4">About SylhetGo</h4>
              <p className="text-sm text-white/80">
                The ultimate smart tourism portal connecting travelers with authentic Sylhet experiences.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-white/80">
                <li><a href="#" className="hover:text-[#2ECC71]">Destinations</a></li>
                <li><a href="#" className="hover:text-[#2ECC71]">Verified Guides</a></li>
                <li><a href="#" className="hover:text-[#2ECC71]">Transport</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">For Providers</h4>
              <ul className="space-y-2 text-sm text-white/80">
                <li><Link to="/guide" className="hover:text-[#2ECC71]">Guide Portal</Link></li>
                <li><Link to="/contributor" className="hover:text-[#2ECC71]">Contributor Portal</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <p className="text-sm text-white/80 mb-3">
                Email: info@sylhetgo.bd<br />
                Phone: +880-821-XXXXXX
              </p>
              <Link to="/admin/login" className="text-xs text-white/40 hover:text-white/60 transition-colors">
                System Admin
              </Link>
            </div>
          </div>
          <div className="border-t border-white/20 pt-6 text-center text-sm text-white/60">
            © 2026 SylhetGo. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
