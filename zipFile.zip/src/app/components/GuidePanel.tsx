import { ArrowLeft, User, MapPin, Star, DollarSign, Calendar, MessageSquare, ToggleLeft, ToggleRight, CheckCircle } from "lucide-react";
import { Link, useNavigate } from "react-router";
import { useState } from "react";

export function GuidePanel() {
  const navigate = useNavigate();
  const [isAvailable, setIsAvailable] = useState(true);

  const handleLogout = () => {
    navigate("/guide");
  };

  return (
    <div className="min-h-screen bg-[#F8F9F9]">
      {/* Header */}
      <nav className="bg-[#0B5345] text-white px-8 py-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/" className="hover:text-[#2ECC71] transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div>
              <h1 className="text-xl font-semibold">Guide Portal</h1>
              <p className="text-xs text-white/80">Manage your profile and bookings</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="bg-red-500 px-4 py-2 rounded-lg text-sm hover:bg-red-600 transition-colors"
          >
            Logout
          </button>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-8 py-12">
        {/* Welcome Section */}
        <div className="bg-gradient-to-r from-[#0B5345] to-[#2ECC71] text-white rounded-xl p-8 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-semibold mb-2">Welcome back, Rafiq Ahmed!</h2>
              <p className="text-white/90">You have 3 pending tour requests and 2 confirmed bookings this week.</p>
            </div>
            <div className="text-right">
              <div className="text-4xl font-bold mb-1">4.9</div>
              <div className="flex items-center justify-end gap-1 mb-1">
                <Star className="w-4 h-4 fill-yellow-300 text-yellow-300" />
                <Star className="w-4 h-4 fill-yellow-300 text-yellow-300" />
                <Star className="w-4 h-4 fill-yellow-300 text-yellow-300" />
                <Star className="w-4 h-4 fill-yellow-300 text-yellow-300" />
                <Star className="w-4 h-4 fill-yellow-300 text-yellow-300" />
              </div>
              <p className="text-sm text-white/80">340 tours completed</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-8">
          {/* Left Column - Profile Management */}
          <div className="col-span-2 space-y-6">
            {/* Profile Settings */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-6">Profile Settings</h3>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-600 mb-2">Full Name</label>
                  <input
                    type="text"
                    defaultValue="Rafiq Ahmed"
                    className="w-full px-4 py-3 bg-[#F8F9F9] rounded-lg outline-none focus:ring-2 focus:ring-[#0B5345]"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-600 mb-2">Specialty</label>
                  <select className="w-full px-4 py-3 bg-[#F8F9F9] rounded-lg outline-none focus:ring-2 focus:ring-[#0B5345]">
                    <option>Tea Estate Expert</option>
                    <option>Cultural Heritage</option>
                    <option>Adventure & Trekking</option>
                    <option>Haor Navigation</option>
                    <option>Photography Tours</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-600 mb-2">Operating Areas</label>
                  <div className="grid grid-cols-2 gap-3">
                    {["Sreemangal", "Ratargul", "Jaflong", "Bholaganj", "Shamshernagar", "Lawachara"].map(area => (
                      <label key={area} className="flex items-center gap-2">
                        <input type="checkbox" defaultChecked={["Sreemangal", "Lawachara"].includes(area)} className="w-4 h-4 text-[#0B5345] rounded" />
                        <span className="text-sm">{area}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm text-gray-600 mb-2">Languages</label>
                  <input
                    type="text"
                    defaultValue="Bengali, English, Hindi"
                    className="w-full px-4 py-3 bg-[#F8F9F9] rounded-lg outline-none focus:ring-2 focus:ring-[#0B5345]"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-600 mb-2">Hourly Rate (৳)</label>
                  <input
                    type="number"
                    defaultValue="500"
                    className="w-full px-4 py-3 bg-[#F8F9F9] rounded-lg outline-none focus:ring-2 focus:ring-[#0B5345]"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-600 mb-2">Bio</label>
                  <textarea
                    rows={4}
                    defaultValue="Passionate about showcasing the beauty of Sreemangal's tea estates. 10+ years of experience guiding international and local tourists."
                    className="w-full px-4 py-3 bg-[#F8F9F9] rounded-lg outline-none focus:ring-2 focus:ring-[#0B5345]"
                  />
                </div>

                <button className="w-full bg-[#2ECC71] text-white py-3 rounded-lg hover:bg-[#27AE60] transition-colors">
                  Update Profile
                </button>
              </div>
            </div>

            {/* Booking Requests */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-6">Pending Booking Requests</h3>

              <div className="space-y-4">
                {[
                  { name: "Sarah Johnson", destination: "Sreemangal Tea Tour", date: "June 15, 2026", duration: "Full Day", amount: "৳4,000" },
                  { name: "Ahmed Hassan", destination: "Lawachara Trek", date: "June 18, 2026", duration: "Half Day", amount: "৳2,500" },
                  { name: "Emily Chen", destination: "Tea Estate Photography", date: "June 20, 2026", duration: "6 hours", amount: "৳3,500" },
                ].map((booking, idx) => (
                  <div key={idx} className="border border-gray-200 rounded-lg p-4 hover:border-[#0B5345] transition-colors">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-semibold text-gray-800">{booking.name}</h4>
                        <p className="text-sm text-gray-600">{booking.destination}</p>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold text-[#0B5345]">{booking.amount}</div>
                        <div className="text-xs text-gray-500">{booking.duration}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                      <Calendar className="w-4 h-4" />
                      <span>{booking.date}</span>
                    </div>
                    <div className="flex gap-2">
                      <button className="flex-1 bg-[#2ECC71] text-white py-2 rounded-lg hover:bg-[#27AE60] transition-colors text-sm">
                        Accept
                      </button>
                      <button className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 transition-colors text-sm">
                        Decline
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column - Status & Stats */}
          <div className="space-y-6">
            {/* Availability Toggle */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Availability Status</h3>

              <div className="flex items-center justify-between mb-4">
                <span className="text-gray-700">Currently {isAvailable ? 'Available' : 'Unavailable'}</span>
                <button
                  onClick={() => setIsAvailable(!isAvailable)}
                  className="relative"
                >
                  {isAvailable ? (
                    <ToggleRight className="w-12 h-12 text-[#2ECC71]" />
                  ) : (
                    <ToggleLeft className="w-12 h-12 text-gray-400" />
                  )}
                </button>
              </div>

              <p className="text-sm text-gray-600 bg-[#F8F9F9] p-3 rounded-lg">
                Toggle this to let tourists know if you're accepting new bookings. You'll stop appearing in search results when unavailable.
              </p>
            </div>

            {/* Verification Badge */}
            <div className="bg-gradient-to-br from-[#2ECC71] to-[#0B5345] text-white rounded-xl shadow-md p-6">
              <div className="flex items-center gap-3 mb-3">
                <CheckCircle className="w-8 h-8" />
                <h3 className="text-lg font-semibold">SylhetGo Verified</h3>
              </div>
              <p className="text-sm text-white/90">
                Your profile has been verified by SylhetGo administrators. This badge increases trust with tourists.
              </p>
            </div>

            {/* Quick Stats */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">This Month</h3>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Tours Completed</span>
                  <span className="font-semibold text-gray-800">12</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Revenue Earned</span>
                  <span className="font-semibold text-[#0B5345]">৳48,500</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">New Reviews</span>
                  <span className="font-semibold text-gray-800">8</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Avg. Rating</span>
                  <span className="font-semibold text-gray-800 flex items-center gap-1">
                    4.9 <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" />
                  </span>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-800">Messages</h3>
                <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">5 New</span>
              </div>

              <div className="space-y-3">
                {[
                  { from: "Sarah Johnson", preview: "What time should we meet?", time: "10m ago" },
                  { from: "SylhetGo Support", preview: "Profile update approved", time: "2h ago" },
                  { from: "Ahmed Hassan", preview: "Can we extend the tour?", time: "5h ago" },
                ].map((msg, idx) => (
                  <div key={idx} className="p-3 bg-[#F8F9F9] rounded-lg hover:bg-gray-100 cursor-pointer transition-colors">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-semibold text-gray-800">{msg.from}</span>
                      <span className="text-xs text-gray-500">{msg.time}</span>
                    </div>
                    <p className="text-xs text-gray-600 truncate">{msg.preview}</p>
                  </div>
                ))}
              </div>

              <button className="w-full mt-4 text-[#0B5345] text-sm hover:underline">
                View All Messages
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
